package com.davidpellegrini.tiptopshave;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        getSupportActionBar().hide();

        setContentView(R.layout.activity_main);

        ScrollView tip1Body = (ScrollView) findViewById(R.id.tip1Body);
        tip1Body.setVisibility(View.GONE);

        ScrollView tip2Body = (ScrollView) findViewById(R.id.tip2Body);
        tip2Body.setVisibility(View.GONE);

        ScrollView tip3Body = (ScrollView) findViewById(R.id.tip3Body);
        tip3Body.setVisibility(View.GONE);

        ScrollView tip4Body = (ScrollView) findViewById(R.id.tip4Body);
        tip4Body.setVisibility(View.GONE);

        ScrollView tip5Body = (ScrollView) findViewById(R.id.tip5Body);
        tip5Body.setVisibility(View.GONE);
    }

    /**
     * Toggle the visibility of the description panel
     * @param view the View that called the method
     */
    public void toggleContents(View view){
        int tag = 0;

        //change the ImageButton icon for the expanded view
        if(view instanceof LinearLayout) {
            tag = Integer.parseInt(view.getTag().toString());
            View button = ((ViewGroup) view).getChildAt(0);
            if (((ImageButton) button).getTag().equals(R.string.closedIBTag)) {
                //closeViews(tag, (ViewGroup) view);
                ((ImageButton) button).setTag(R.string.openIBTag);
                ((ImageButton) button).setImageResource(R.drawable.ic_keyboard_arrow_right_24dp);
            } else {
                ((ImageButton) button).setTag(R.string.closedIBTag);
                ((ImageButton) button).setImageResource(R.drawable.ic_keyboard_arrow_down_24dp);
            }
        }
        else if(view instanceof ImageButton){
            ViewGroup parentView = (ViewGroup) view.getParent();
            tag = Integer.parseInt(parentView.getTag().toString());

            if (((ImageButton) view).getTag().equals(R.string.closedIBTag)) {
                //closeViews(parentView);
                ((ImageButton) view).setTag(R.string.openIBTag);
                ((ImageButton) view).setImageResource(R.drawable.ic_keyboard_arrow_right_24dp);
            } else {
                ((ImageButton) view).setTag(R.string.closedIBTag);
                ((ImageButton) view).setImageResource(R.drawable.ic_keyboard_arrow_down_24dp);
            }
        }

        //find the ScrollView below the selected tip and expand/collapse
        for (int i = 2; i <= 10; i+= 2){
            if(i != tag + 1) {
                findViewById(R.id.contentPanel).findViewWithTag(Integer.toString(i)).setVisibility(View.GONE);
            }
        }

        ScrollView targetTip = (ScrollView) findViewById(R.id.contentPanel).findViewWithTag(Integer.toString(tag + 1));
        targetTip.setVisibility(targetTip.isShown() ? View.GONE : View.VISIBLE);
    }

   /* public void closeViews(int tag, View button){
        ImageButton closingView = (ImageButton) findViewById(R.id.contentPanel).findViewWithTag(R.string.openIBTag);
        String flag = Integer.toString(R.string.closedIBTag);
        if(closingView != null) {
            closingView.setTag(R.string.closedIBTag);
            closingView.setImageResource(R.drawable.ic_keyboard_arrow_right_24dp);
        }
    }*/
}
